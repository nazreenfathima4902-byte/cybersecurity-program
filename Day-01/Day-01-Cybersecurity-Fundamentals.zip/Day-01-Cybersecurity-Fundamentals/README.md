# Day 01 – Cybersecurity Fundamentals

## 📚 Training Topic

Cyber Security Essentials

---

## 🎯 Topics Covered

During Day 01, I studied the fundamentals of cybersecurity, including:

1. Cybersecurity Threats, Vulnerabilities, and Attacks
2. Common Threats
3. Deception
4. Cyber Attacks
5. Wireless and Mobile Device Attacks
6. Application Attacks
7. Cybersecurity Threats, Vulnerabilities, and Attacks Summary

---

## 1. Cybersecurity Threats, Vulnerabilities, and Attacks

### Cybersecurity Threats

A cybersecurity threat is a potential danger that can affect the security of a computer system, network, device, or data.

### Vulnerability

A vulnerability is a weakness or security flaw that can be exploited.

### Attack

A cyber attack is an attempt to exploit a vulnerability in order to affect a system, network, device, or data.

### Basic Relationship

```text
Threat
   ↓
Vulnerability
   ↓
Attack
   ↓
Possible Security Impact
```

---

## 2. Common Threats

Cybersecurity involves understanding different types of threats that can affect systems and networks.

The training syllabus covers common cybersecurity threats as part of the Cybersecurity Threats, Vulnerabilities, and Attacks module.

### Important Things to Understand

- What a cybersecurity threat is
- How vulnerabilities can create security risks
- How attackers can exploit weaknesses
- How attacks can affect systems and data
- The importance of identifying security weaknesses

---

## 3. Deception

Deception is included as a topic under cybersecurity threats, vulnerabilities, and attacks.

It involves misleading or manipulating users or systems as part of an attack.

### Key Point

Security awareness is important because attackers may attempt to deceive users into taking actions that can compromise security.

---

## 4. Cyber Attacks

A cyber attack is an attempt to compromise or exploit a computer system, network, device, application, or data.

Cyber attacks can target different parts of an organization's technology environment.

### Areas Covered in the Training

- Network-related attacks
- Wireless and mobile device attacks
- Application attacks

---

## 5. Wireless and Mobile Device Attacks

Wireless and mobile devices can also be targeted by attackers.

The syllabus specifically includes:

- Wireless attacks
- Mobile device attacks

These attacks are studied as part of the Cybersecurity Threats, Vulnerabilities, and Attacks module.

---

## 6. Application Attacks

Applications can contain weaknesses that attackers may attempt to exploit.

Application attacks are therefore an important part of cybersecurity.

### Key Areas to Understand

- Applications can have vulnerabilities
- Attackers may attempt to exploit application weaknesses
- Application security is an important part of overall cybersecurity

---

## 🔐 Key Cybersecurity Concepts

| Term | Meaning |
|------|---------|
| Threat | A potential danger to a system or data |
| Vulnerability | A weakness that can be exploited |
| Attack | An attempt to exploit a weakness |
| Cybersecurity | Protection of systems, networks, devices, and data |
| Deception | Misleading or manipulating users/systems |
| Application Attack | An attack targeting an application |
| Wireless Attack | An attack targeting wireless communication/devices |
| Mobile Device Attack | An attack targeting mobile devices |

---

## 🧠 What I Learned

From Day 01, I learned the basic concepts required to understand cybersecurity.

### Main Learning Points

- Understanding cybersecurity threats
- Understanding vulnerabilities
- Understanding cyber attacks
- Understanding the relationship between threats, vulnerabilities, and attacks
- Learning about common threats
- Understanding deception as a cybersecurity topic
- Learning about wireless and mobile device attacks
- Understanding application attacks

---

## 📝 Important Definitions

### Threat

A potential danger that may affect a system, network, device, or data.

### Vulnerability

A weakness that can potentially be exploited.

### Cyber Attack

An attempt to exploit a weakness in a system, network, application, device, or data.

### Deception

An approach involving misleading or manipulating users or systems.

---

## 💡 Key Takeaways

```text
Threat
   ↓
Identifies a potential danger

Vulnerability
   ↓
Represents a weakness

Attack
   ↓
Attempts to exploit the weakness

Security
   ↓
Helps protect systems, networks, devices, and data
```

---

## 🛠️ Practical Work

### Practical Activities

- Reviewed basic cybersecurity terminology
- Identified the difference between threats, vulnerabilities, and attacks
- Studied different categories of cyber attacks
- Reviewed wireless and mobile device attacks
- Reviewed application attacks

### Commands / Tools Used

No specific commands or tools are listed for Day 01 in the provided syllabus.

---

## 📌 Revision Checklist

- [ ] What is a cybersecurity threat?
- [ ] What is a vulnerability?
- [ ] What is a cyber attack?
- [ ] What is the difference between a threat and a vulnerability?
- [ ] What is deception?
- [ ] What are wireless and mobile device attacks?
- [ ] What are application attacks?
- [ ] Why is understanding vulnerabilities important?

---

## 📖 Training Source

**Cyber Security – Complete Course Syllabus & Training Plan**

Stage: **Stage 1 – Cyber Security Essentials**

Topics covered are based on the uploaded cybersecurity training syllabus.

---

## 🚀 Day 01 Status

**Status:** Completed ✅

**Focus:** Cybersecurity Fundamentals

**Next:** Day 02 – Network Security Fundamentals
